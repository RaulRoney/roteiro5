public class MinhaPilha {

    private int size;
    private Integer[] myData;
    private int top;

    public MinhaPilha(int size) {
        this.size = size;
        this.myData = new Integer[size];
        this.top = -1;
    }

    public MinhaPilha() {
        this(10); // Tamanho padrão da pilha é 10
    }

    public void push(Integer item) {
        if (top == size - 1) {
            throw new IllegalStateException("A pilha está cheia");
        }
        top++;
        myData[top] = item;
    }

    public Integer pop() {
        if (isEmpty()) {
            throw new IllegalStateException("A pilha está vazia");
        }
        Integer item = myData[top];
        myData[top] = null;
        top--;
        return item;
    }

    public Integer top() {
        if (isEmpty()) {
            throw new IllegalStateException("A pilha está vazia");
        }
        return myData[top];
    }

    public MinhaPilha multitop(int k) {
        if (k <= 0 || k > size) {
            throw new IllegalArgumentException("O valor de k deve ser positivo e menor ou igual ao tamanho da pilha");
        }

        MinhaPilha subPilha = new MinhaPilha(k);
        for (int i = top; i > top - k; i--) {
            subPilha.push(myData[i]);
        }
        return subPilha;
    }

    public boolean isEmpty() {
        return top == -1;
    }
}
